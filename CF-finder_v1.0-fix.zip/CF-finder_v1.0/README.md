>> BY TheKoba-dev <<
>> MIT LICENSE << 

>> yuzlerce dns serverdan istek atarak CloudFlare a ait omayan ip adresini arar "ilgili domain için" 
>> başarısız olması nedeniyle rafa kalkmıştır 

>> Belgeleme tarhihi <<
>> 07.11.2022 << 

